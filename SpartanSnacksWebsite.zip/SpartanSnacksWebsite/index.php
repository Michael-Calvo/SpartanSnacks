<?php
$title = "Home";
$content = "Welcome to SpartanSnacks!";

include 'Template.php';


?>